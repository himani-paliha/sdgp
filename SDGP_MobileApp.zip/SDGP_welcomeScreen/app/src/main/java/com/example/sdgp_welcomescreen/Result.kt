package com.example.sdgp_welcomescreen

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button

class Result : Activity() {

    private lateinit var homeButton: Button
    private lateinit var exitButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_results)

        homeButton = findViewById(R.id.home_button)

        homeButton.setOnClickListener {
            val Intent= Intent(this,MainActivity::class.java)
            startActivity(Intent)
        }
    }
}
