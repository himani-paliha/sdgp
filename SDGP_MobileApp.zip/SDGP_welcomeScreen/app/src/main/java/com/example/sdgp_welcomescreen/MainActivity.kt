package com.example.sdgp_welcomescreen

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView

class MainActivity : Activity() {

    private val REQUEST_IMAGE_CAPTURE = 1
    private val REQUEST_IMAGE_FROM_GALLERY = 2

    private lateinit var imageView: ImageView
    private lateinit var takePictureButton: Button
    private lateinit var choosePictureButton: Button
    private lateinit var confirmButton: Button
    private lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        takePictureButton = findViewById(R.id.capture_button)
        choosePictureButton = findViewById(R.id.upload_Button)
        confirmButton = findViewById(R.id.confirm_button)
        backButton = findViewById(R.id.back_button)

        confirmButton.isEnabled = false
        backButton.isEnabled = false

        takePictureButton.setOnClickListener {
            dispatchTakePictureIntent()
        }

        choosePictureButton.setOnClickListener {
            dispatchChoosePictureIntent()
        }

        confirmButton.setOnClickListener {
            val Intent= Intent(this,Result::class.java)
            startActivity(Intent)
        }

        backButton.setOnClickListener {
            imageView.setImageBitmap(null)
            confirmButton.isEnabled = false
            backButton.isEnabled = false
            takePictureButton.isEnabled = true
            choosePictureButton.isEnabled = true
        }
    }

    private fun dispatchTakePictureIntent() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(packageManager) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
        }
        confirmButton.isEnabled = true
        backButton.isEnabled = true
        takePictureButton.isEnabled = false
        choosePictureButton.isEnabled = false
    }

    private fun dispatchChoosePictureIntent() {
        val choosePictureIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        if (choosePictureIntent.resolveActivity(packageManager) != null) {
            startActivityForResult(choosePictureIntent, REQUEST_IMAGE_FROM_GALLERY)
        }
        confirmButton.isEnabled = true
        backButton.isEnabled = true
        takePictureButton.isEnabled = false
        choosePictureButton.isEnabled = false
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_IMAGE_CAPTURE -> {
                    val imageBitmap = data?.extras?.get("data") as Bitmap
                    imageView.setImageBitmap(imageBitmap)
                }
                REQUEST_IMAGE_FROM_GALLERY -> {
                    val selectedImageUri: Uri? = data?.data
                    val imageBitmap = MediaStore.Images.Media.getBitmap(contentResolver, selectedImageUri)
                    imageView.setImageBitmap(imageBitmap)
                }
            }

            takePictureButton.isEnabled = false
            choosePictureButton.isEnabled = false
            confirmButton.isEnabled = true
            backButton.isEnabled = true
        }
    }
}
